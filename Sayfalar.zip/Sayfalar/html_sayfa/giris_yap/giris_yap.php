<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<div class="panel-heading">Giriş Yap
    </div>
<form action="javascript:;" id="giris" method="post">

<input type="hidden" name="kayit_token" value="<?=$ayar->sessionid;?>">

<table border="0" align="center" width="100%">
  
  	<tbody>
	<tr>
      <td  align="center"><label>Kullanıcı Adı:<span style="color:darkred;text-shadow:none;">*</span><br>
      <input name="username" class="form-control" onkeyup="turkce_kontrol(this)"  type="text" value=""></label>
	  <input type="hidden"  value="<?=$ayar->sessionid;?>" name="giris_token" />
      </td>
      </tr>
	<tr>
      <td align="center"><label>Şifre:<span style="color:darkred;text-shadow:none;">*</span><br>
        <input name="pass" class="form-control" type="password">
      </label></td>
      </tr>
	      <tr>
      <td align="center">
	  <br>
	  	<button class="g-recaptcha btn btn-giris" type="submit" value="Giriş Yap">Giriş Yap</button>
	  <br><br>
	  <?php if($vt->a("kullanici_unuttum") == 1){?><a href="kullanici-adi-unuttum">Kullanıcı adını mı unuttun ?</a> <br> <br><?php } ?>
	  <a href="sifremi-unuttum">Şifreni mi unuttun ? </a>
	  </td>
	  
    </tr>

    </tbody>
	</table>
	
	</form>
