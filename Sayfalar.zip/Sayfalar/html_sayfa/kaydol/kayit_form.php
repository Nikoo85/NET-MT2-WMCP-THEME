
        <div class="col-md-12 no-padding-all">
            <center><h3>Kayıt Ol</h3></center>
            <h2 class="brackets"></h2>
        </div>
    <div class="col-md-12">
<script>
function refreshCaptcha() {
	$("img#captcha_code").attr('src','<?=WMcaptcha;?>');
}
</script>
		        <form action="javascript:;" method="post" id="kaydol" class="form-horizontal">
				<input type="hidden" name="kayit_token" value="<?=$ayar->sessionid;?>">
            <div class="form-group has-feedback">
                <label for="regpassword" class="col-sm-4 control-label">Kullanıcı Adı <span class="text-danger">*</span></label>

                <div class="col-sm-5">
                    <input type="text" class="form-control grunge" name="username" onkeyup="turkce_kontrol(this)" id="login" >
                    <i class="fa fa-user form-control-feedback"></i>
            </div>

            </div>
            <div class="form-group has-feedback">
                <label for="regpassword" class="col-sm-4 control-label">Şifre <span class="text-danger">*</span></label>

                <div class="col-sm-5">
                    <input type="password" class="form-control grunge" name="pass">
                    <i class="fa fa-lock form-control-feedback"></i>
                </div>
            </div>
            <div class="form-group has-feedback">
                <label for="regpassword" class="col-sm-4 control-label">Şifre Tekrar <span class="text-danger">*</span></label>

                <div class="col-sm-5">
                    <input type="password" class="form-control grunge" name="pass_retry">
                    <i class="fa fa-lock form-control-feedback"></i>
                </div>

            </div>
            <div class="form-group has-feedback">
                <label for="regpassword" class="col-sm-4 control-label">Mail Adresi <span class="text-danger">*</span></label>

                <div class="col-sm-5">
                    <input type="text" class="form-control grunge" name="eposta" value="">
                    <i class="fa fa-envelope form-control-feedback"></i>
                </div>
            </div>
            <div class="form-group has-feedback">
                <label for="regpassword" class="col-sm-4 control-label">İsim Soyisim <span class="text-danger">*</span></label>

                <div class="col-sm-5">
                    <input id="name" type="text" name="real_name" class="form-control grunge" onkeyup="turkce_kontrol(this)" type="text" value="">
                    <i class="fa fa-edit form-control-feedback"></i>
                </div>
            </div>
            <div class="form-group has-feedback">
                <label for="regpassword" class="col-sm-4 control-label">Karakter Silme Kodu <span class="text-danger">*</span></label>

                <div class="col-sm-5">
                    <input id="ksk" type="text" name="social_id" class="form-control grunge" onkeyup="sayi_kontrol(this)" maxlength="7">
                    <i class="fa fa-lock form-control-feedback"></i>
                </div>
            </div>
            <div class="form-group has-feedback">
                <label for="regpassword" class="col-sm-4 control-label">Telefon <span class="text-danger">*</span></label>

                <div class="col-sm-5">
                    <input type="text" id="phone" name="phone_number" class="form-control grunge" onkeyup="sayi_kontrol(this)" maxlength="11" placeholder="555-555-55-55">
                    <i class="fa fa-phone form-control-feedback"></i>
                </div>
        		</div>
	
	
            <div class="form-group has-feedback">
                <label for="regpassword" class="col-sm-4 control-label">Robot Kontrol <span class="text-danger">*</span></label>

                		<tr>
		<td align="center">
		<img src="<?=WMcaptcha;?>" id="captcha_code" /> <a href="javascript:;" onClick="refreshCaptcha();"><img src="<?=$ayar->WMimg;?>refresh.png" /></a></td>
	</tr>           
	                <div class="col-sm-5">
                    <input  type="text" name="captcha_code" class="form-control grunge" autocomplete="off">
                    <i class="fa fa-lock form-control-feedback"></i>
                </div>
	</div>
	

	
	

	
            <div class="row">
                <div class="col-sm-7 col-sm-offset-4">
                    <label for="terms">Üyelik Sözleşmesi</label>
                    <div class="terms">
                        <ul class="list-unstyled">
                            <li>
                            </li><li>Yaş Sınırlaması</li>
                            <li>13-18 Yaş arasındaki oyuncu adaylarının ebeveyn isteği dışında sisteme kayıt olmaları yasaktır.</li>
                            <li>13 Yaş altındaki oyuncu adaylarının sisteme kayıt olması kesinlikle yasaktır.</li>
                            <li>Oyun içerisinde tespit edilen 13 yaş altı oyuncuların hesapları kişinin belirtilen yaşını doldurana kadar kapatılacaktır.</li>
                                <br>
                            <li>Ücretsiz Oyun</li>
                            <li>Oyun tamamen ücretsiz olarak oynanabildiği gibi, yardımcı nesnelerin kullanımı , belirtilen fiyatlarda ödeme yapılarak sağlanabilmektedir.</li>
                            <li>Ödeme yapan kişi herhangi bir sebepten dolayı ceza alırsa veya kapatılırsa hak talebinde bulunamaz.</li>
                                <br>
                            <li>Yardımcı nesneler için kesinlikle değişim ve soyulma olaylarında iade yapılmayacaktır.</li>
                                <br>
                            <li>Geri Dönüşüm</li>
                            <li> Kullanıcıların kendi karakterlerini geliştirmek amacı ile yaptığı ödemeler karşılıksız kalmaz, Sistem Güçlendirme / Geliştirme Çalışmalarıyla kullanıcılara hizmet kalitesi olarak geri dönecektir.</li>
                                <br>
                            <li>Engelli Hesaplar</li>
                            <li>Kullanıcıların hesapları , Ceza sistemi'nde bulunan süreli veya süresiz kapatılma cezalarını aldıklarında oyun içinde faydalandıkları yardımcı nesnelerin kesinlikle iadeleri yapılmaz.</li>
                            <li>Eğer bir açık bulup bunu kendinize avantaj sağlamak için kullanırsanız oyun hesabınız cezalandırılır. Bulunan tüm oyun ve programlama açıkları derhal Destek Sistemi kullanılarak oyun takımına iletilmelidir.</li>
                            <li>Destek sistemine gönderilen sahte resim,video ve benzeri unsurlar için tarafların başlatacağı hukuki işlemlerde NetMT2 MMORPG yönetimi sorumlu değildir.</li>
                            <li>Sorumluluk, öğeyi gönderen oyuncu ve kapatılan oyuncunundur.</li>
                            <li>3-)Hiç bir oyuncu oyuna ait hiç bir ortamda diğer oyuncuları gerçek hayata yönelik olarak tehdit edemez ve gerçek hayata yönelik eylemlere zorlayamaz. Oyuna yönelik tehditler bu madde kapsamı dışındadır. Herhangi bir oyuncuyu, takım üyesini, NetMT2 MMORPG sorumlusunu, yada herhangi bir şekilde oyun servisleri ile ilgili birini bulup ona zarar verileceğine yönelik imalar ve söylemler kesinlikle yasaktır.</li>
                            <li>Oyun Yöneticileri uygun görmediği bir oyuncunun hesabını sebep belirtmeksizin kapatabilir.</li>
                                <br>
                            <li>Hesap Paylaşımı</li>
                            <li>Kullanıcı bilgilerinin paylaşımı kesinlikle yasaktır.</li>
                            <li>Hesabın veya oyun içindeki herhangi bir eşyanın, başka kişi ya da kurumlara Ücret (TL, $, EURO vs) , Oyun Parası (Yang) veya Ejder Parası (EP) karşılığında Satılması Kesinlikle yasaktır.</li>
                            <li>Serverlar arası eşya takası,alış veya satışı yasaktır.</li>
                            <li>Hesapların takası durumunda hiçbir Oyun Yöneticisi, Moderatörü vs. sorumlu tutulamaz. Tarafların kendi aralarındaki meseledir. Sorumluluk taraflarındır.</li>
                                <br>
                            <li>Dosya Paylaşımı / Hesap Soyulmaları / Eşya Çalınması</li>
                            <li>Oyun içindeki diğer kullanıcılardan veya internet bağlantılarıyla alınan dosyalardan gelebilecek olan ve bilgisayarınızda çalıştırıldığında klavyede basılan her tür harf,sayı vb. karakterlerin kaydedilmesi durumunda hesap soyulmaları meydana gelmektedir.</li>
                            <li>Hesap güvenliği tamamen kullanıcıya aittir ve bu gibi durumlarda çalınan hesap, nesne vs. geri iadesi söz konusu değildir.</li>
                            <li>Eğer ispat edilirse sadece suçlu hesap süresiz kapatılır.</li>
                                <br>
                            <li>Hesap Güvenliği</li>
                            <li>NetMT2 MMORPG olarak hesabınızı güvenlik şifresi sistemi ve güvenli bilgisayar sistemi ile de ek olarak korumaktayız.</li>
                            <li>Eğer güvenli bilgisayar tanımlamazsanız hesabınızın soyulma ihtimali artar.</li>
                            <li>Soyulma durumlarında yetkililer hiçbir şekilde eşya iadesi yapmayacaklardır.</li>
                            <li>Hesabınızın çalınması durumunda yöneticilerin durum değerlendirmesine bağlı olarak hesap geri verilebilir.</li>
                                <br>
                            <li>Oyuncular Arası İletişim</li>
                            <li>Oyun içerisinde, oyuncular arası ilişkiler sonucu gerçek hayatta ortaya çıkabilecek hiçbir olaydan NetMT2 MMORPG Yönetimi sorumlu tutulamaz.</li>
                            <li>Oyun kayıtları içerisinde gerçek hayata yönelik tehditler tespit edilir veya bildirilirse sorumlu hesaplar süresiz kapatılır.</li>
                                <br>
                            <li>ÖNEMLİ !</li>
                                <br>
                            <li>YAPILAN BAĞIŞ SADECE SERVER AÇIK KALMASI İÇİNDİR Yukarıda Belirtilen Maddelerde Belirtilen Durumlarda Oluşabilecek Hiçbir Sıkıntıdan Oyun Yöneticileri Sorumlu Tutulamaz.</li>
                            <li>Kurallara aykırı olan davranış ve tutumlara Hiçbir şekilde tolerans gösterilmeyecektir.</li>
                            <li>Kayıt olan , Oyuna giriş yapan ve Oyun hizmetlerinden yararlanan tüm kullanıcılar Üyelik ve Hizmet Sözleşmesini kabul etmiş sayılır.</li>
                            <li>Olası bir iade konusunda NetMT2 MMORPG takımı kanıt istemekde yükümlüdür.NetMT2 MMORPG Takımını tatmin etmeyen kanıtlar geçersiz sayılıp iade işlemi yapılmayacakdır.</li>
                            <li>EP Alanlar mutlaka ScreenShot gibi kanıtlar yanlarında bulundurmalıdırlar.(Dekont,video,screenshot vs.)</li>
                                <br>
                            <li>NetMT2 MMORPG Yönetimi,</li>
                            <li>Üyelik ve Hizmet Sözleşmesi'nde belirtilen maddeleri değiştirme hakkını gizli tutar. </li>
                        </ul>                        </div>
                    <span>      <td align="center">
        <input type="checkbox" name="sozlesme" id="checkbox" value="1" checked style="float:none; margin:0; padding:0; height: 15px;">
		<label for="checkbox">
        <strong></strong> <br> okudum ve kabul ediyorum.</label><br></td></span>
                </div>
            </div>
			
			
            <div class="row">
                <div class="form-inline col-sm-offset-4 col-sm-8">
                   <br> <button type="submit" class="btn btn-grunge" value="Kayıt ol">Kayıt Ol</button>
                </div><br>
            </div>
        </form>
		<br><br>
    </div>

