<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<a href="oyuncu-siralamasi"><< Karakter Sıralamasına Dön</a>

<div style="margin-bottom:20px"></div>
