<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div class="tablo_wm wm_youtube">Tanıtım Videomuz</div>
<div class="tablo_icerik wm_youtube_icerik">
	
<iframe width="410" height="315" src="https://www.youtube.com/embed/<?=$vt->sosyal(3);?>" frameborder="0" allowfullscreen></iframe>


</div>
