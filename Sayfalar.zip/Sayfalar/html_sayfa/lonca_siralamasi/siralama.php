<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

        <div class="row">
<div class="col-md-3">
                <div class="rank-img rank-img-menu">
                    <h3>Menu</h3>
                </div>
                <ul id="ranking-menu" class="rankings-nav" style="margin-top: 10px">
                    <li> <a href="oyuncu-siralamasi" data-type="playerrank"><span class="img char">p</span><span>Oyuncu Sıralaması</span></a></li>
                    <li class="active"> <a href="lonca-siralamasi" data-type="guildrank"><span class="img guild"></span><span>Lonca Sıralaması</span></a></li>
                </ul>
            </div>
<div class="col-md-9">
                <div class="rank-img rank-img-chars">
                    <h3 id="ranking-title">Oyuncu Sıralaması</h3>
                </div>
                <div id="ajaxLoader">
                    <div id="ranking-result" style="margin-top: 18px;"><div class="container-tab rankings-cont">
		<table class="table table-rankings">
                                <thead>
                                <tr>
                                    <td>#</td>
                                    <td>İsim</td>

                                    <td>Seviye</td>
                                    <td>Lonca Puanı</td>
                                    <td>Bayrak</td>

                                    <td>Kazanma</td>
                                    <td>Lider</td>
                                </tr>
                                </thead>
                                <tbody>


		<?php 
						$i = $limit;
	foreach($query as $row){
	$i++;
	$uyeler = $odb->prepare("SELECT COUNT(guild_member.pid) AS COUNT FROM player.guild_member WHERE guild_id = ?");
	$uyeler->execute(array($row["id"]));
	$uyeler = $uyeler->fetchColumn();
	?>
	
						<tr>
							<td><?=$i;?></td>
							<td style="text-align:left;"><?=$row["name"];?></td>
							<td class="hidden-xs"><?=$row["level"];?></td>
							<td class="hidden-xs"><?=$row["ladder_point"];?></td>
							<td><img src="<?=$ayar->WMimg.'bayrak/'.$row["empire"];?>.jpg"></td>
							<td class="hidden-xs"><?=$uyeler;?></td>
							<td class="hidden-xs"><?=$row["lider"];?></td>

						</tr>

	<?php 
	}
	?>

                                																                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>