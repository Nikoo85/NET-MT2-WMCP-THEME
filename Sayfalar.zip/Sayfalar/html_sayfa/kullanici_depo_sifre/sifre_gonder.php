<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div class="alert alert-warning"><strong>BİLGİ ! </strong>Depo Şifrenizi değiştirmek için, gönder butonuna tıkladıktan sonra e-postanıza gelen linke tıklamalısınız. </div>

<form action="javascript:;" method="post" id="deposifresi" variable="sifremail">
<a href="kullanici"><input type="button" value="K. Paneline Dön"></a>
<input name="depo_sifre_degistir_1" type="submit" value="Gönder" />

</form>
