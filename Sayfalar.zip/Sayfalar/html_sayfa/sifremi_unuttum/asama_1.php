<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<div class="panel-heading">Şifre Sıfırlama
    </div>
<form action="javascript:;" id="sifremi_unuttum" method="post" variable="sifremiunuttum">

<table border="0" align="center" width="100%">
	    <tr>
      <td  align="center"><label>Kullanıcı Adınızı Giriniz<span style="color:darkred;text-shadow:none;">*</span><br>
		<input type="hidden" name="sifre_unuttum_token" value="<?=$ayar->sessionid;?>">
        <input name="kullanici" class="form-control" type="text">
      </label></td>
    </tr>
	    <tr>
      <td align="center"><label>E-mail Adresinizi Giriniz<span style="color:darkred;text-shadow:none;">*</span><br>
        <input name="email" class="form-control" type="text">
      </label></td>
    </tr>
		<tr>
		<td align="center">
		<img src="<?=WMcaptcha;?>" id="captcha_code" /> <a href="javascript:;" onClick="refreshCaptcha();"><img src="<?=$ayar->WMimg;?>refresh.png" /></a></td>
	</tr>
	
	
     <tr>
      <td align="center"><label>Güvenlik Kodu:<span style="color:darkred;text-shadow:none;">*</span><br><br>
          <input name="captcha_code" class="form-control" type="text" autocomplete="off"><br><br>
          </label></td>
    </tr>
    <tr>
      <td align="center">
	  <br>
	<button class="g-recaptcha btn btn-giris" type="submit" name="sifre_unuttum" value="Gönder">Gönder</button>
    </tr>
</table>

</form>



