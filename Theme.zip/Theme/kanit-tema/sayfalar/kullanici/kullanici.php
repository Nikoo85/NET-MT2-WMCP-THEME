<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

		        <span class="clear"><!-- --></span>
		<div class="col-md-12">
        <h2 class="header-2" style="text-align: center;text-shadow: 0 0 3px #c17373;padding-bottom: 2px;background: url(<?=WM_tema;?>app/public/client/default/media/images/calc-divider.jpg) 50% 100% no-repeat;"></h2>
    </div>        <center><h4>Hesap : <?=$_SESSION[$vt->a("isim")."username"];?> </h4></center>
		<div class="col-md-12">
        <h2 class="header-2" style="text-align: center;text-shadow: 0 0 3px #c17373;padding-bottom: 2px;background: url(<?=WM_tema;?>/app/public/client/default/media/images/calc-divider.jpg) 50% 100% no-repeat;"></h2>
    </div>        <center><h4>Email : <?=$vt->uye("email");?></h4></center>
		<div class="col-md-12">
        <h2 class="header-2" style="text-align: center;text-shadow: 0 0 3px #c17373;padding-bottom: 2px;background: url(<?=WM_tema;?>app/public/client/default/media/images/calc-divider.jpg) 50% 100% no-repeat;"></h2>
    </div>        <center><h4>Telefon : <?=$WMinf->kisalt($vt->uye("phone1"), 7, "****");?></h4></center>
		<div class="col-md-12">
        <h2 class="header-2" style="text-align: center;text-shadow: 0 0 3px #c17373;padding-bottom: 2px;background: url(<?=WM_tema;?>app/public/client/default/media/images/calc-divider.jpg) 50% 100% no-repeat;"></h2>
    </div>        <center><h4>Ep Miktarı : <?=$vt->uye("coins");?></h4></center>
		<div class="col-md-12">
        <h2 class="header-2" style="text-align: center;text-shadow: 0 0 3px #c17373;padding-bottom: 2px;background: url(<?=WM_tema;?>app/public/client/default/media/images/calc-divider.jpg) 50% 100% no-repeat;"></h2>
    </div>        <center><h4>Bayrak : <?=$tema->_bayrak($vt->uye("id"));?></h4></center>
		<div class="col-md-12">
        <h2 class="header-2" style="text-align: center;text-shadow: 0 0 3px #c17373;padding-bottom: 2px;background: url(<?=WM_tema;?>app/public/client/default/media/images/calc-divider.jpg) 50% 100% no-repeat;"></h2>
    </div> 

	 <div class="col-md-6">
<a class="btn btn-block btn-grunge" href="kullanici/bildirimler"> Bildirimler (<?=$bildirimler->rowCount();?>)</a>
<?php if($vt->a("kullanici_degis") != 3){?><a class="btn btn-block btn-grunge" href="kullanici/kullanici-adi-degistir">Kullanıcı Adı Değiştir</a><?php } ?>
<a class="btn btn-block btn-grunge" href="kullanici/sifre-degistir">Şifre Değiştir</a>
<?php if($vt->a("mail_degistir") == 1){?><a class="btn btn-block btn-grunge" href="kullanici/mail-degistir">Mail Değiştir</a><?php } ?>
<a class="btn btn-block btn-grunge" href="kullanici/karakter-silme-sifresi-degistir" ><?=($vt->a("karakter_silme_sifre") == 1 || $vt->a("karakter_silme_sifre") == 3) ? "K. Silme Ş. Değiştir" : "K. Silme Ş. İste";?></a>
<a class="btn btn-block btn-grunge" href="kullanici/depo-sifre-degistir"><?=($vt->a("depo_sifre") == 1 || $vt->a("depo_sifre") == 3) ? "Depo Şifre Değiştir" : "Depo Şifre Gönder";?></a>
<?php if($ep_transfer->errorInfo()[2] == false){ if($e_durum->errorInfo()[2] == false){ if($vt->uye("edurum") == 1){ if($eptransayar[1] == 1){ 
if($eptransayar[4] == 1){ ?> 
<a class="btn btn-block btn-grunge" href="kullanici/ep-gonder-sifre-degistir">Ep T. Şifresi Değiştir</a>
<?php } } } } } ?>
<a class="btn btn-block btn-grunge" href="kullanici/bugdan-kurtar">Bugdan Kurtar</a>
<a class="btn btn-block btn-grunge" href="<?=$vt->url(7);?>">Teknik Destek</a>
<?php if($davet_kontrol->errorInfo()[2] == false){ ?><a class="btn btn-block btn-grunge" href="kullanici/davet-et">Arkadaşını Davet Et</a><?php }  ?>
<?php if($ep_token->errorInfo()[2] == false){ ?> <a class="btn btn-block btn-grunge" href="kullanici/ep-tokenlerim">Ep Tokenlerim</a> <a class="btn btn-block btn-grunge" href="kullanici/ep-token-kullan">Ep Token Kullan</a><?php } ?>
<a class="btn btn-block btn-grunge" href="kullanici/giris-loglari">Giriş Logları</a>
<a class="btn btn-block btn-grunge" href="kullanici/level-loglari">Level Logları</a>
<a class="btn btn-block btn-grunge" href="kullanici/market-loglari">Marketten Aldıklarım</a>
<a class="btn btn-block btn-grunge" href="kullanici/karakterlerim">Karakterlerim (<?=$tema->kac_karakter($_SESSION[$vt->a("isim")."userid"]);?>)</a>
<a class="btn btn-block btn-grunge" href="kullanici/basvuru">Başvuru Yap</a>
        </div>

        <div class="col-md-6">

			        </div>

