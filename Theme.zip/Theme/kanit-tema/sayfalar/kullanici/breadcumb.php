<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div class="row">
<ol class="breadcrumb grunge">
<li><a href="index.php">Anasayfa</a></li>
<li><a href="<?=$vt->url(5);?>">Hesabım</a> > </li>
<li><?=$_SESSION[$vt->a("isim")."username"];?> </li>

</div>

<br>
