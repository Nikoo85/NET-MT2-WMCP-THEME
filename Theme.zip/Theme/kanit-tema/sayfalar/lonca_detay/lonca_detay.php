<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div class="bg-light item-container">
                        <div class="player-informations">
						
                            <h3>Detaylı Bilgi</h3>
							
							
                            <div class="player-table">
                                <div class="player-row">
                                    <strong><i class="icon-man position-left"></i> Puan:</strong>
                                    <span><?=$ll["ladder_point"];?></span>
                                </div>

                                <div class="player-row">
                                    <strong><i class="icon-height position-left"></i> Seviye:</strong>
                                    <span><?=$ll["level"];?></span>
                                </div>

                                <div class="player-row">
                                    <strong><i class="icon-flag4 position-left"></i> Exp:</strong>
                                    <span><?=$ll["exp"];?></span>
                                </div>
								


                                <div class="player-row">
                                    <strong><i class="icon-watch2 position-left"></i> Kazanma:</strong>
                                    <span><?=$ll["win"];?></span>
                                </div>
                                <div class="player-row">
                                    <strong><i class="icon-watch2 position-left"></i> Kaybetme:</strong>
                                    <span><?=$ll["loss"];?></span>
                                </div>
                                <div class="player-row">
                                    <strong><i class="icon-watch2 position-left"></i> Beraberlik:</strong>
                                    <span><?=$ll["draw"];?></span>
                                </div>

                                <div class="player-row">
                                    <strong><i class="icon-watch position-left"></i> Lider:</strong>
                                    <span><span title="<?=$ll["baskan"];?>"></span></span>
                                </div>
								

                            </div>

							
                        </div>
                        <div class="player-flag" style="background-color: rgba(84, 14, 14, 0.54);"></div>
                    </div>


