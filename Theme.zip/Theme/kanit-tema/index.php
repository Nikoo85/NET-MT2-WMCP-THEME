<?php 
require_once 'sayfalar/class.php';

$srv = new server;

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Meta start -->
    <meta charset="UTF-8">
    <meta name="robots" content="follow, index"/>
    <meta http-equiv="Content-Language" content="pl"/>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="index.php">
    <title>NetMT2 MMORPG - Metin2 Orta Emek Server</title>

	<?php $wmcp->head(); ?>
	<?php $tema->stiller(); ?>

    <!-- /meta start -->

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="https://netm2.com/site/favicon.ico" sizes="16x16" />
    <!-- /favicon -->

    <!-- Meta -->
    <meta name="keywords" content="metin2, NetMT2 MMORPG, emek, medium, metin, pvp server metin2"/>
    <meta name="description" content="NetMT2 MMORPG pvp server Metin2 emek/zor."/>
    <!-- /meta -->

    <!-- OpenGraph tags (espec. Facebook) -->
    <meta property="og:type" content="article"/>
    <meta property="og:url" content="https://netm2.com/site/"/>
    <meta property="og:title" content="NetMT2 MMORPG - Metin2 PVP Server"/>
    <meta property="og:description" content="NetMT2 MMORPG-Metin2 PVP Server. Uzun süre boyunca, hoş dengeli ve ilginç oyun sunuyoruz!"/>
    <meta property="og:image" content="https://netm2.com/site/data/upload/M9TeWQhrU8UcMkI.png"/>
    <!-- /openGraph tags -->

    <link rel="stylesheet" href="<?=WM_tema;?>app/public/client/default/media/css/styles.css">
	<link rel="stylesheet" href="<?=WM_tema;?>nikoo85.css">
    <link rel="stylesheet" href="<?=WM_tema;?>app/public/client/default/media/css/alertify.css">
    <link rel="stylesheet" href="<?=WM_tema;?>app/public/client/default/media/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?=WM_tema;?>app/public/client/default/media/css/bootstrap-social.css">
    <link rel="stylesheet" href="<?=WM_tema;?>app/public/client/default/media/css/jquery.bxslider.min.css">
    <link rel="stylesheet" href="<?=WM_tema;?>app/public/client/default/media/css/flag-icon.min.css">
    <link href="<?=WM_tema;?>app/public/client/default/media/css/fancybox.css" rel="stylesheet" type="text/css" media="screen"/>
    <link href="<?=WM_tema;?>app/public/client/default/media/css/jquery.fancybox.min.css" rel="stylesheet" type="text/css" media="screen"/>
    <script src="<?=WM_tema;?>app/public/client/default/media/javascripts/jquery-2.1.4.min.js" type="text/javascript"></script>
    <script src="<?=WM_tema;?>app/public/client/default/media/javascripts/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?=WM_tema;?>app/public/client/default/media/javascripts/alertify.js" type="text/javascript"></script>
    <script src="<?=WM_tema;?>app/public/client/default/media/javascripts/jquery-ui.js" type="text/javascript"></script>
    <script src="<?=WM_tema;?>app/public/client/default/media/javascripts/jquery.bxslider.min.js" type="text/javascript"></script>
    <script src="<?=WM_tema;?>app/public/client/default/media/javascripts/jquery.blockUI.js" type="text/javascript"></script>
    <script src="<?=WM_tema;?>app/public/client/default/media/javascripts/script.js" type="text/javascript"></script>
    <script type="text/javascript" src="<?=WM_tema;?>app/public/client/default/media/javascripts/fancybox.js"></script>
    <script type="text/javascript" src="<?=WM_tema;?>app/public/client/default/media/javascripts/jquery.fancybox.min.js"></script>
    <script type="text/javascript" src="<?=WM_tema;?>app/public/client/default/media/javascripts/notify.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            var screenSize = $(window).height();
            var compareW = 767;
            if (screenSize > 0 && screenSize < compareW) {
                var fancy_a = 740;
                var fancy_b = 550;
                var fancy_c = "ishopbg-small";
                var fancy_d = "13px";
                var fancy_e = "3px";
                var fancy_f = "13px";
                var fancy_g = 754;
                var fancy_h = 574;
                var fancy_i = 6;
                var fancy_j = 20;
            }
            else
            {
                var fancy_a = 1016;
                var fancy_b = 655;
                var fancy_c = "ishopbg";
                var fancy_d = "16px";
                var fancy_e = "7px";
                var fancy_f = "16px";
                var fancy_g = 1032;
                var fancy_h = 690;
                var fancy_i = 8;
                var fancy_j = 28;
            }
            var fancybox_css = {
                'outer': {'background': null},
                'close': {'background_image': null, 'height': null, 'right': null, 'top': null, 'width': null}
            };
            $('a.itemshop').fancybox({
                'autoDimensions': false,
                'width': fancy_a,
                'height': fancy_b,
                'padding': 0,
                'scrolling': 'yes',
                'overlayColor': '#000',
                'overlayOpacity': 0.8,
                'onStart': function () {
                    fancybox_css.outer.background = $('#fancybox-outer').css('background');
                    fancybox_css.close.background_image = $('#fancybox-close').css('background-image');
                    fancybox_css.close.height = $('#fancybox-close').css('height');
                    fancybox_css.close.right = $('#fancybox-close').css('right');
                    fancybox_css.close.top = $('#fancybox-close').css('top');
                    fancybox_css.close.width = $('#fancybox-close').css('width');
                    $('#fancybox-outer').css({'background': 'transparent url("https://netm2.com/site/app/public/client/default/static/images/'+fancy_c+'.png") center center no-repeat'});
                    $('#fancybox-close').css({
                        'background-image': 'none',
                        'cursor': 'pointer',
                        'height': fancy_d,
                        'right': '3px',
                        'top': fancy_e,
                        'width': fancy_f
                    });
                },
                'onComplete': function () {
                    $('#fancybox-inner').css({'top': fancy_j, 'left': fancy_i});
                    $('#fancybox-wrap').css({'width': fancy_g, 'height': fancy_h});
                },
                'onClosed': function () {
                    if (null != fancybox_css.outer.background) {
                        $('#fancybox-outer').css('background', fancybox_css.outer.background);
                    }
                    if (null != fancybox_css.close.background_image) {
                        $('#fancybox-close').css('background-image', fancybox_css.close.background_image);
                    }
                    if (null != fancybox_css.close.height) {
                        $('#fancybox-close').css('height', fancybox_css.close.height);
                    }
                    if (null != fancybox_css.close.right) {
                        $('#fancybox-close').css('right', fancybox_css.close.right);
                    }
                    if (null != fancybox_css.close.top) {
                        $('#fancybox-close').css('top', fancybox_css.close.top);
                    }
                    if (null != fancybox_css.close.width) {
                        $('#fancybox-close').css('width', fancybox_css.close.width);
                    }
                }
            });
        });
    </script>
</head>


<body>
<div id="sonuc"></div>
	    <style>
        .languagepicker {
            background-color: #FFF;
            display: inline-block;
            padding: 0;
            height: 40px;
            overflow: hidden;
            transition: all .3s ease;
            margin: 30px 0 0 0;
            vertical-align: top;
            float: left;
            position: fixed;
            right: 0px;
            z-index: 999;
        }

        .languagepicker:hover {
            /* don't forget the 1px border */
            height: 81px;
        }

        .languagepicker a{
            color: #000;
            text-decoration: none;
        }

        .languagepicker li {
            display: block;
            padding: 0px 10px;
            line-height: 40px;
            border-top: 1px solid #EEE;
        }

        .languagepicker li:hover{
            background-color: #EEE;
        }

        .languagepicker a:first-child li {
            border: none;
            background: #FFF !important;
        }

        .languagepicker li img {
            margin-top: 0px;
        }

        .roundborders {
            -webkit-border-top-left-radius: 5px;
            -webkit-border-bottom-left-radius: 5px;
            -moz-border-radius-topleft: 5px;
            -moz-border-radius-bottomleft: 5px;
            border-top-left-radius: 5px;
            border-bottom-left-radius: 5px;
        }

        .large:hover {
            height: 135px;
        }
    </style>
    <ul class="languagepicker roundborders large">
					                <a href="javascript:void(0)"><li><img src="https://netm2.com/site/data/flags/country/tr.png"/></li></a>
																									                <a href="https://netm2.com/site/languages/select/en"><li><img src="https://netm2.com/site/data/flags/country/en.png"/></li></a>
								                <a href="https://netm2.com/site/languages/select/de"><li><img src="https://netm2.com/site/data/flags/country/de.png"/></li></a>
					    </ul>
<header class="main">
    <div class="container">
        <nav class="navbar navbar-default navbar-main" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse"
                            data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="logo-container">
                        <a class="navbar-brand" href="https://netm2.com/site/index">
                            <img src="https://netm2.com/site/data/upload/M9TeWQhrU8UcMkI.png" alt="">
                        </a>
                    </div>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li><a class="active" href="index.php">Anasayfa</a></li>
						                            <li><a href="kaydol">Kayıt Ol</a></li>
						                        <li><a href="oyunu-indir">Oyunu indir</a></li>
                        <li><a class="itemshop itemshop-btn iframe"
                               href="market">Market</a></li>
                        <li><a href="oyuncu-siralamasi">Sıralama</a></li>
                        <li><a href="https://www.darkmmo.com/" target="_blank">Forum</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</header>
<div class="container page-container">
<div class="row">
            <div class="col-md-9">
                <div class="bx-wrapper" style="max-width: 100%; margin: 0px auto;"><div class="bx-viewport" style="width: 100%; overflow: hidden; position: relative; height: 320px;"><div class="bxslider" style="width: auto; position: relative;">
                    <div style="float: none; list-style: none; position: absolute; width: 848px; z-index: 0; display: none;">
                        <a href="index.php">
                            <img src="<?=WM_tema;?>app/public/client/default/media/banners/slide-1.png">
                        </a>
                    </div>
                    <div style="float: none; list-style: none; position: absolute; width: 848px; z-index: 50; display: block;">
                        <a href="index.php">
                            <img src="<?=WM_tema;?>app/public/client/default/media/banners/slide-2.png">
                        </a>
                    </div>
                </div></div><div class="bx-controls bx-has-controls-direction"><div class="bx-controls-direction"><a class="bx-prev" href="">Prev</a><a class="bx-next" href="">Next</a></div></div></div>
            </div>
            <div class="col-md-3 spot-right">
                <a href="index.php" class="download-button">Hemen Oyna</a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 sub-spot">
								                <div class="col-md-3">
                    <div class="rank-tabs">
                        <ul id="myTab" class="nav nav-pills sub-spot-title-list">
                            <li class="sub-spot-title">
                                <h4>En iyi Oyuncular</h4>
                            </li>
                        </ul>
                            <div id="rank-player" class="tab-content"
                                 style="min-height: 158px; position: static; zoom: 1;">
                                <div class="tab-pane active">
                                    <ul class="mini-rank list-group">
									<?=$srv->karakter(5);?>
									</ul>
                                </div>
                            </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="rank-tabs">
                        <ul id="myTab" class="nav nav-pills sub-spot-title-list">
                            <li class="sub-spot-title">
                                <h4>En iyi Loncalar</h4>
                            </li>
                        </ul>
                            <div id="rank-guild" class="tab-content" style="min-height: 158px; position: static; zoom: 1;">
                                <div class="tab-pane active">
                                    <ul class="mini-rank list-group">
									<?=$srv->lonca(5);?>
																					                                    </ul>
                                </div>
                            </div>
                    </div>
                </div>
																                <div class="col-md-3">
										                    <div class="unique-times">
                        <ul id="myTab" class="nav nav-pills sub-spot-title-list">
                            <li class="sub-spot-title">
                                <h4>Sunucu İstatistikleri</h4>
                            </li>
                        </ul>
                        <div class="tab-content" style="min-height: 158px; position: static; zoom: 1;">
                        <ul class="times list-unstyled" id="last_unique">
														                                    <li>
                                    <span class="badge" id="online_oyuncu">ERROR</span>
                                    <span class="circle"></span>
                                    <span class="name">Toplam Online</span>
                                </li>
															    							                                    <li>
                                    <span class="badge" id="toplam_kayit">ERROR</span>
                                    <span class="circle"></span>
                                    <span class="name">Toplam Hesap</span>
                                </li>
																								                            <li class="live">
                                <span class="badge">Online</span>
                                <span class="circle"></span>
                                <span class="name">Game Server</span>
                            </li>
                            <li class="live">
                                <span class="badge">Online</span>
                                <span class="circle"></span>
                                <span class="name">DB Server</span>
                            </li>
							                        </ul>
                    </div>
                    </div>
																				                </div>
                <div class="col-md-3">
					                        <div class="login-cont frame" style="margin-bottom: 15px;">
							                                <div class="frame-inner" style="margin: -1px;">
									
									<?php if(!isset($_SESSION[$vt->a("isim")."token"])){ ?>
															
                                    <form method="post" action="javascript:;" id="giris">
                                        <input type="hidden" name="giris_csrf_token" value="<?=$ayar->sessionid;?>">
										<input type="hidden" value="<?=$ayar->sessionid;?>" name="giris_token" />
                                        <div class="form-group narrow">
                                            <input type="text" class="form-control grunge" id="login" name="username"
                                                   placeholder="Kullanıcı Adı">
                                            <span class="endbtn"></span>
                                        </div>
                                        <div class="form-group narrow">
                                            <input type="password" class="form-control grunge" id="password" name="pass"
                                                   placeholder="Şifre">
                                        </div>

                                        <button type="submit" name="login-submit" class="btn btn-block btn-grunge">Giriş Yap</button>
                                    </form>
									
									                                    <h5 class="login-reg-link">
                                        <a href="sifremi-unuttum">
                                            <span class="glyphicon glyphicon-chevron-right"></span> Şifremi Unuttum</a>
                                        <br>
                                        <a href="kaydol">
                                            <span class="glyphicon glyphicon-chevron-right"></span> Hemen Kayıt Ol</a>
                                    </h5>
									</div>
							<?php }else{ ?>
								

							
							<div class="login-cont frame" style="margin-top: 10px;">
                            <div class="col-md-12 login-cont-profile">
                                <div class="col-xs-4 login-cont-avatar" style="background-image:url(<?=WM_tema;?>app/public/client/default/media/images/default-avatar.png);"></div>
                                <div class="col-xs-8 no-padding-right">
                                    <div class="dropdown dd-grunge">
                                        <a <b><h4> <?=$_SESSION[$vt->a("isim")."username"];?></b></h4></a>
                                    </div>
                                    <p>
                                        <small><a  href="cikis-yap">Çıkış Yap<span class="glyphicon glyphicon-log-out"></span></a></small>
                                    </p>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="col-md-12 text-muted">
                                <ul style="margin-left:-15px;">
                                    <li>
                                      <a href="javascript:;"> <strong>Ejderha Parası : <?=$vt->uye("coins");?></a></strong>

                                    </li>

                                </ul>
                            </div>
                            <div class="clearfix"></div>
                            <ul>
                                <li><a href="kullanici">Hesabım</a></li>
                                <li><a class="itemshop itemshop-btn iframe" href="https://www.darkmmo.com">EP Satın Al</a></li>
                                <li><a class="itemshop itemshop-btn iframe" href="market">Nesne Market</a></li>
                                <li><a href="destek" target="_blank">Destek</a></li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
								
							<?php } ?>
									

                                
							                        </div>
					                </div>
            </div>
        </div>

<div class="col-md-9 no-padding-left">
    <div class="list-group news">
        <div id="blog-articles">

            <div class="clearfix"></div>
            <div class="col-md-12">
<div align=""> <?=$wmcp->orta();?>    </div>    
            </div>
            <div class="clearfix"></div>
            <div class="col-md-12 no-padding-all">
												    				            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<script>
    $('#load-mores').click(function () {
        var url = "http://localhost/tema2-backup/index/patch2";
        var data = $('#patchCount').text();
        var newsCount = "1";
        $.post(url, {data: data}, function (result) {
            if (result.data == "") {
                $('#load-more-container').remove();
                return false;
            } else {
                $('#blog-articles').append(result.data);
                $('#patchCount').text(result.count)
            }
        }, "json");
    });
</script>
<div class="col-md-3">
    <div class="col-md-12 no-padding-all">
        <div class="list-group news">
            <div class="subspot-link-bg">
                <a href="https://netm2.com/index.html" class="subspot-link-image donate-link">
                    <br>Tanıtım <br><br>
                </a>
            </div>
            <div class="subspot-link-bg">
                <a href="https://mt2.tc/forums/30-NETM2" class="subspot-link-image donate-links">
                    <br>Forum <br><br>
                </a>
            </div>
            <div class="subspot-link-bg">
                <a href="https://www.facebook.com/Net2Game/" class="btn btn-block btn-social btn-facebook">
                    <span class="fa fa-facebook"></span> Facebook
                </a>
            </div>
            <div class="subspot-link-bg">
                <a href="https://www.youtube.com/channel/UC-TWYpKt3hQMpZcxD-kKBNA/" class="btn btn-block btn-social btn-google">
                    <span class="fa fa-youtube"></span> YouTube
                </a>
            </div>


            <div class="unique-times">
                <ul id="myTab" class="nav nav-pills sub-spot-title-list">
                    <li class="sub-spot-title">
                        <h4>Etkinlik Takvimi</h4>
                    </li>
                </ul>
                <div class="center-block">
                    <iframe src="https://netm2.com/site/event" style="border: none;width: 140px;height: 275px;margin-right: auto;margin-left: auto;margin-top: 20px" id="fancybox-frame"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div><footer class="main">
    <div class="container">
        <div class="row">
            <div class="footer-nav col-md-3">
                <h4><span class="glyphicon glyphicon-tower"></span> Menu</h4>
                <ul class="list-unstyled">
                    <li><a href="index.php">Anasayfa</a></li>
                    <li><a href="oyunu-indir">Oyunu indir</a></li>
                    <li><a class="itemshop itemshop-btn iframe" href="market">Market</a></li>
                    <li><a href="oyuncu-siralamasi">Oyuncu Sıralaması</a></li>
                    <li><a href="lonca-siralamasi">Lonca Sıralaması</a></li>
                </ul>
            </div>
            <div class="footer-nav col-md-3">
                <h4><span class="glyphicon glyphicon-user"></span> Hesabım</h4>
                <ul class="list-unstyled">
                                            <li><a href="giris-yap">Giriş Yap</a></li>
                        <li><a href="kaydol">Kayıt Ol</a></li>
                        <li><a href="sifremi-unuttum">Şifremi Unuttum</a></li>
                                    </ul>
            </div>
            <div class="footer-nav col-md-3">
                <h4><span class="glyphicon glyphicon-globe"></span> Sosyal</h4>
                <ul class="list-unstyled">
                    <li><a href="https://www.darkmmo.com" target="_blank">Forum</a>
                    </li>
                    <li><a href="https://www.facebook.com/" target="_blank">Facebook</a>
                    </li>
                    <li><a href="https://www.youtube.com/" target="_blank">Youtube</a>
                    </li>
                </ul>
            </div>
            <div class="footer-nav col-md-3">
                <h4><span class="glyphicon glyphicon-cog"></span> Destek</h4>
                <ul class="list-unstyled">
                    <li><a class="itemshop itemshop-btn iframe" href="destek">Destek</a></li>
                    <li><a href="index.php">Kullanıcı Sözleşmesi</a></li>
                </ul>
            </div>
        </div>
        <div class="row footer-text">
            <div class="col-md-12 text-center"><!-- Global site tag (gtag.js) - Google Analytics --><script async src="https://www.googletagmanager.com/gtag/js?id=UA-121971849-2"></script><script>  window.dataLayer = window.dataLayer || [];  function gtag(){dataLayer.push(arguments);}  gtag('js', new Date());  gtag('config', 'UA-121971849-2');</script>
                <p>
                    Copyright &copy; by <a href="https://www.darkmmo.com">Darkmmo</a> - 20189<br />
                    Tüm hakları saklıdır ve <a href="https://www.darkmmo.com">Furkan Çelebi GKANOS / Nikoo85</a> mülkiyetindedir.<br />

                </p>
            </div>
        </div>
    </div>
</footer>
<?php 
$tema->jquery($konum); 
$tema->footer();
?>	

</body>
</html>